# ejercicios/hola.py
print("Hola mundo!")